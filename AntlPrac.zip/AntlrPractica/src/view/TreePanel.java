package view;

import javax.swing.*;
import java.awt.*;
import java.util.List;

class TreePanel extends JPanel {
    private TreeNode root;

    public TreePanel(TreeNode root) {
        this.root = root;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (root != null) {
            drawTree(g, root, getWidth() / 2, 30, getWidth() / 4, 50);
        }
    }

    private void drawTree(Graphics g, TreeNode node, int x, int y, int xOffset, int yOffset) {
        g.drawString(node.value, x - g.getFontMetrics().stringWidth(node.value) / 2, y);
        int childCount = node.children.size();
        int nextXOffset = xOffset / 2;

        for (int i = 0; i < childCount; i++) {
            TreeNode child = node.children.get(i);
            int childX = x - xOffset + (2 * i * xOffset / (childCount > 1 ? (childCount - 1) : 1));
            int childY = y + yOffset;
            g.drawLine(x, y + 10, childX, childY - 10);
            drawTree(g, child, childX, childY, nextXOffset, yOffset);
        }
    }
}
