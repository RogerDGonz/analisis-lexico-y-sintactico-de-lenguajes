package view;

import javax.swing.*;

public class TreeVisualizer {
	
	private TreeNode root;
	
    public TreeVisualizer(TreeNode root) {
        // Crear un �rbol de ejemplo
        this.root = root;

        // Crear el panel de dibujo
        TreePanel treePanel = new TreePanel(root);

        // Crear la ventana principal
        JFrame frame = new JFrame("�rbol Gen�rico");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(treePanel);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
    
    public TreeNode getRoot() {
    	return root;
    }
    
}