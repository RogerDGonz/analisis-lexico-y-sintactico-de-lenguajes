package view;

import org.antlr.v4.runtime.tree.ParseTree;

public class TreeNodeConverter {

    public static TreeNode convert(ParseTree parseTree) {
        // Crear un TreeNode a partir del texto del ParseTree actual
        TreeNode node = new TreeNode(parseTree.getText());

        // Recorrer todos los hijos del ParseTree y convertirlos
        for (int i = 0; i < parseTree.getChildCount(); i++) {
            ParseTree child = parseTree.getChild(i);
            // Convertir el hijo y a�adirlo como hijo del TreeNode actual
            node.addChild(convert(child));
        }

        return node;
    }
}
