package main;

import java.io.IOException;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import logic.JsonParser;
import logic.JsonLexer;

import view.*;

public class Main {
	
	public static void main(String[] args) {
		CharStream input = null;
		try {
			input = CharStreams.fromFileName("C:\\Users\\Usuario\\ANTLR\\arr.txt");
		} catch(IOException ex) {
			System.out.println("Error opening input file: " + ex);
		}
		JsonLexer lexer = new JsonLexer(input);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		JsonParser parser = new JsonParser(tokens);
		ParseTree parseTree = parser.r(); // Comienza a parsear a partir de la regla r
		
		TreeNode root = TreeNodeConverter.convert(parseTree.getChild(0).getChild(0));

		new TreeVisualizer(root);
		
	}

}
